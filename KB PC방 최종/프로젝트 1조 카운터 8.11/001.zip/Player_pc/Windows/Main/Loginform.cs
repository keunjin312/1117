﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Player_pc.Windows.Pop;

namespace Player_pc {
    public partial class Loginform : Form {
        public Loginform() {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e) {

        }

        private void Log_join_btn_Click(object sender, EventArgs e) {
            JoinPop _pop = new JoinPop();
            if (_pop.ShowDialog(this) == DialogResult.OK) {

            }
        }

        private void Log_find_id_Click(object sender, EventArgs e) {
            FindIdPop _pop = new FindIdPop();
            if (_pop.ShowDialog(this) == DialogResult.OK) {

            }
        }

        private void Log_find_pw_Click(object sender, EventArgs e) {
            FindPwPop _pop = new FindPwPop();
            if (_pop.ShowDialog(this) == DialogResult.OK) {

            }
        }
    }
}
