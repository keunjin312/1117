﻿using mainPC.mainPC.회원관리;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mainPC {
    public partial class counter_main : Form {
        public counter_main() {
        InitializeComponent();
        }

        //회원관리창 열기
        private void CM_member_mg_Click(object sender, EventArgs e) {
        Member_management pop = new Member_management();
        pop.ShowDialog(this);
        }
    }
}
