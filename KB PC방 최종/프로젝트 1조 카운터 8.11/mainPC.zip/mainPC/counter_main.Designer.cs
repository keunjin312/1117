﻿namespace mainPC {
    partial class counter_main {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing) {
        if (disposing && (components != null)) {
        components.Dispose();
        }
        base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.CM_screen_lock = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.CM_product_mg = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.CM_member_mg = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.menu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CM_payment = new System.Windows.Forms.ToolStripMenuItem();
            this.CM_system = new System.Windows.Forms.ToolStripMenuItem();
            this.CM_system_shutdown = new System.Windows.Forms.ToolStripMenuItem();
            this.CM_system_restart = new System.Windows.Forms.ToolStripMenuItem();
            this.CM_add_time = new System.Windows.Forms.ToolStripMenuItem();
            this.CM_add_time_1hour = new System.Windows.Forms.ToolStripMenuItem();
            this.CM_add_time_2hour = new System.Windows.Forms.ToolStripMenuItem();
            this.CM_add_time_3hour = new System.Windows.Forms.ToolStripMenuItem();
            this.CM_add_time_5hour = new System.Windows.Forms.ToolStripMenuItem();
            this.CM_reserved = new System.Windows.Forms.ToolStripMenuItem();
            this.CM_breakdown = new System.Windows.Forms.ToolStripMenuItem();
            this.CM_Shift = new System.Windows.Forms.ToolStripMenuItem();
            this.CM_seat_1 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.CM_seat_2 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.CM_seat_3 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.CM_seat_4 = new System.Windows.Forms.Panel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.panel33 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.CM_seat_5 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.panel37 = new System.Windows.Forms.Panel();
            this.panel38 = new System.Windows.Forms.Panel();
            this.panel39 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.CM_seat_6 = new System.Windows.Forms.Panel();
            this.panel41 = new System.Windows.Forms.Panel();
            this.panel42 = new System.Windows.Forms.Panel();
            this.panel43 = new System.Windows.Forms.Panel();
            this.panel44 = new System.Windows.Forms.Panel();
            this.panel45 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.CM_seat_7 = new System.Windows.Forms.Panel();
            this.panel47 = new System.Windows.Forms.Panel();
            this.panel48 = new System.Windows.Forms.Panel();
            this.panel49 = new System.Windows.Forms.Panel();
            this.panel50 = new System.Windows.Forms.Panel();
            this.panel51 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.CM_seat_8 = new System.Windows.Forms.Panel();
            this.panel53 = new System.Windows.Forms.Panel();
            this.panel54 = new System.Windows.Forms.Panel();
            this.panel55 = new System.Windows.Forms.Panel();
            this.panel56 = new System.Windows.Forms.Panel();
            this.panel57 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.CM_seat_9 = new System.Windows.Forms.Panel();
            this.panel59 = new System.Windows.Forms.Panel();
            this.panel60 = new System.Windows.Forms.Panel();
            this.panel61 = new System.Windows.Forms.Panel();
            this.panel62 = new System.Windows.Forms.Panel();
            this.panel63 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.CM_seat_10 = new System.Windows.Forms.Panel();
            this.panel65 = new System.Windows.Forms.Panel();
            this.panel66 = new System.Windows.Forms.Panel();
            this.panel67 = new System.Windows.Forms.Panel();
            this.panel68 = new System.Windows.Forms.Panel();
            this.panel69 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.CM_seat_11 = new System.Windows.Forms.Panel();
            this.panel71 = new System.Windows.Forms.Panel();
            this.panel72 = new System.Windows.Forms.Panel();
            this.panel73 = new System.Windows.Forms.Panel();
            this.panel74 = new System.Windows.Forms.Panel();
            this.panel75 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.CM_seat_12 = new System.Windows.Forms.Panel();
            this.panel77 = new System.Windows.Forms.Panel();
            this.panel78 = new System.Windows.Forms.Panel();
            this.panel79 = new System.Windows.Forms.Panel();
            this.panel80 = new System.Windows.Forms.Panel();
            this.panel81 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.CM_seat_13 = new System.Windows.Forms.Panel();
            this.panel83 = new System.Windows.Forms.Panel();
            this.panel84 = new System.Windows.Forms.Panel();
            this.panel85 = new System.Windows.Forms.Panel();
            this.panel86 = new System.Windows.Forms.Panel();
            this.panel87 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.CM_seat_14 = new System.Windows.Forms.Panel();
            this.panel89 = new System.Windows.Forms.Panel();
            this.panel90 = new System.Windows.Forms.Panel();
            this.panel91 = new System.Windows.Forms.Panel();
            this.panel92 = new System.Windows.Forms.Panel();
            this.panel93 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.CM_seat_15 = new System.Windows.Forms.Panel();
            this.panel95 = new System.Windows.Forms.Panel();
            this.panel96 = new System.Windows.Forms.Panel();
            this.panel97 = new System.Windows.Forms.Panel();
            this.panel98 = new System.Windows.Forms.Panel();
            this.panel99 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel9.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel10.SuspendLayout();
            this.menu.SuspendLayout();
            this.CM_seat_1.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.CM_seat_2.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel21.SuspendLayout();
            this.CM_seat_3.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel27.SuspendLayout();
            this.CM_seat_4.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel33.SuspendLayout();
            this.CM_seat_5.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel39.SuspendLayout();
            this.CM_seat_6.SuspendLayout();
            this.panel43.SuspendLayout();
            this.panel45.SuspendLayout();
            this.CM_seat_7.SuspendLayout();
            this.panel49.SuspendLayout();
            this.panel51.SuspendLayout();
            this.CM_seat_8.SuspendLayout();
            this.panel55.SuspendLayout();
            this.panel57.SuspendLayout();
            this.CM_seat_9.SuspendLayout();
            this.panel61.SuspendLayout();
            this.panel63.SuspendLayout();
            this.CM_seat_10.SuspendLayout();
            this.panel67.SuspendLayout();
            this.panel69.SuspendLayout();
            this.CM_seat_11.SuspendLayout();
            this.panel73.SuspendLayout();
            this.panel75.SuspendLayout();
            this.CM_seat_12.SuspendLayout();
            this.panel79.SuspendLayout();
            this.panel81.SuspendLayout();
            this.CM_seat_13.SuspendLayout();
            this.panel85.SuspendLayout();
            this.panel87.SuspendLayout();
            this.CM_seat_14.SuspendLayout();
            this.panel91.SuspendLayout();
            this.panel93.SuspendLayout();
            this.CM_seat_15.SuspendLayout();
            this.panel97.SuspendLayout();
            this.panel99.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(844, 60);
            this.panel1.TabIndex = 3;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.CM_screen_lock);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel5.Location = new System.Drawing.Point(237, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(115, 60);
            this.panel5.TabIndex = 2;
            // 
            // CM_screen_lock
            // 
            this.CM_screen_lock.BackColor = System.Drawing.Color.DarkGray;
            this.CM_screen_lock.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_screen_lock.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_screen_lock.Location = new System.Drawing.Point(0, 0);
            this.CM_screen_lock.Name = "CM_screen_lock";
            this.CM_screen_lock.Size = new System.Drawing.Size(115, 60);
            this.CM_screen_lock.TabIndex = 1;
            this.CM_screen_lock.Text = "화면잠금";
            this.CM_screen_lock.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.CM_product_mg);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(122, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(115, 60);
            this.panel4.TabIndex = 1;
            // 
            // CM_product_mg
            // 
            this.CM_product_mg.BackColor = System.Drawing.Color.DarkGray;
            this.CM_product_mg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_product_mg.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_product_mg.Location = new System.Drawing.Point(0, 0);
            this.CM_product_mg.Name = "CM_product_mg";
            this.CM_product_mg.Size = new System.Drawing.Size(115, 60);
            this.CM_product_mg.TabIndex = 1;
            this.CM_product_mg.Text = "상품관리";
            this.CM_product_mg.UseVisualStyleBackColor = false;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.CM_member_mg);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(122, 60);
            this.panel3.TabIndex = 0;
            // 
            // CM_member_mg
            // 
            this.CM_member_mg.BackColor = System.Drawing.Color.DarkGray;
            this.CM_member_mg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_member_mg.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_member_mg.Location = new System.Drawing.Point(0, 0);
            this.CM_member_mg.Name = "CM_member_mg";
            this.CM_member_mg.Size = new System.Drawing.Size(122, 60);
            this.CM_member_mg.TabIndex = 0;
            this.CM_member_mg.Text = "회원관리";
            this.CM_member_mg.UseVisualStyleBackColor = false;
            this.CM_member_mg.Click += new System.EventHandler(this.CM_member_mg_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel9);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 60);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(844, 392);
            this.panel2.TabIndex = 4;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.tableLayoutPanel1);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(237, 0);
            this.panel9.Name = "panel9";
            this.panel9.Padding = new System.Windows.Forms.Padding(3);
            this.panel9.Size = new System.Drawing.Size(607, 392);
            this.panel9.TabIndex = 1;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_15, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_14, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_13, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_12, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_11, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_10, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_9, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_8, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_7, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_6, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_5, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_4, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(601, 386);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkGray;
            this.panel6.Controls.Add(this.panel8);
            this.panel6.Controls.Add(this.panel10);
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(237, 392);
            this.panel6.TabIndex = 0;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.dataGridView1);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(0, 126);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(237, 266);
            this.panel8.TabIndex = 2;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(237, 266);
            this.dataGridView1.TabIndex = 0;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.label1);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel10.Location = new System.Drawing.Point(0, 94);
            this.panel10.Name = "panel10";
            this.panel10.Padding = new System.Windows.Forms.Padding(7);
            this.panel10.Size = new System.Drawing.Size(237, 32);
            this.panel10.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(7, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(223, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "<상품 주문 관리>";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel7
            // 
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(237, 94);
            this.panel7.TabIndex = 0;
            // 
            // menu
            // 
            this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CM_payment,
            this.CM_system,
            this.CM_add_time,
            this.CM_reserved,
            this.CM_breakdown,
            this.CM_Shift});
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(151, 136);
            // 
            // CM_payment
            // 
            this.CM_payment.Name = "CM_payment";
            this.CM_payment.Size = new System.Drawing.Size(150, 22);
            this.CM_payment.Text = "결제 및 종료";
            // 
            // CM_system
            // 
            this.CM_system.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CM_system_shutdown,
            this.CM_system_restart});
            this.CM_system.Name = "CM_system";
            this.CM_system.Size = new System.Drawing.Size(150, 22);
            this.CM_system.Text = "전원";
            // 
            // CM_system_shutdown
            // 
            this.CM_system_shutdown.Name = "CM_system_shutdown";
            this.CM_system_shutdown.Size = new System.Drawing.Size(150, 22);
            this.CM_system_shutdown.Text = "시스템 종료";
            // 
            // CM_system_restart
            // 
            this.CM_system_restart.Name = "CM_system_restart";
            this.CM_system_restart.Size = new System.Drawing.Size(150, 22);
            this.CM_system_restart.Text = "스스템 재시작";
            // 
            // CM_add_time
            // 
            this.CM_add_time.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CM_add_time_1hour,
            this.CM_add_time_2hour,
            this.CM_add_time_3hour,
            this.CM_add_time_5hour});
            this.CM_add_time.Name = "CM_add_time";
            this.CM_add_time.Size = new System.Drawing.Size(150, 22);
            this.CM_add_time.Text = "이용시간 추가";
            // 
            // CM_add_time_1hour
            // 
            this.CM_add_time_1hour.Name = "CM_add_time_1hour";
            this.CM_add_time_1hour.Size = new System.Drawing.Size(133, 22);
            this.CM_add_time_1hour.Text = "1시간 추가";
            // 
            // CM_add_time_2hour
            // 
            this.CM_add_time_2hour.Name = "CM_add_time_2hour";
            this.CM_add_time_2hour.Size = new System.Drawing.Size(133, 22);
            this.CM_add_time_2hour.Text = "2시간 추가";
            // 
            // CM_add_time_3hour
            // 
            this.CM_add_time_3hour.Name = "CM_add_time_3hour";
            this.CM_add_time_3hour.Size = new System.Drawing.Size(133, 22);
            this.CM_add_time_3hour.Text = "3시간 추가";
            // 
            // CM_add_time_5hour
            // 
            this.CM_add_time_5hour.Name = "CM_add_time_5hour";
            this.CM_add_time_5hour.Size = new System.Drawing.Size(133, 22);
            this.CM_add_time_5hour.Text = "5시간 추가";
            // 
            // CM_reserved
            // 
            this.CM_reserved.Name = "CM_reserved";
            this.CM_reserved.Size = new System.Drawing.Size(150, 22);
            this.CM_reserved.Text = "좌석 예약";
            // 
            // CM_breakdown
            // 
            this.CM_breakdown.Name = "CM_breakdown";
            this.CM_breakdown.Size = new System.Drawing.Size(150, 22);
            this.CM_breakdown.Text = "좌석 고장";
            // 
            // CM_Shift
            // 
            this.CM_Shift.Name = "CM_Shift";
            this.CM_Shift.Size = new System.Drawing.Size(150, 22);
            this.CM_Shift.Text = "자리 이동";
            // 
            // CM_seat_1
            // 
            this.CM_seat_1.Controls.Add(this.panel15);
            this.CM_seat_1.Controls.Add(this.panel14);
            this.CM_seat_1.Controls.Add(this.panel11);
            this.CM_seat_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_1.Location = new System.Drawing.Point(3, 3);
            this.CM_seat_1.Name = "CM_seat_1";
            this.CM_seat_1.Size = new System.Drawing.Size(114, 122);
            this.CM_seat_1.TabIndex = 0;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.panel13);
            this.panel11.Controls.Add(this.panel12);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(114, 27);
            this.panel11.TabIndex = 0;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.label2);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel12.Location = new System.Drawing.Point(0, 0);
            this.panel12.Name = "panel12";
            this.panel12.Padding = new System.Windows.Forms.Padding(2);
            this.panel12.Size = new System.Drawing.Size(33, 27);
            this.panel12.TabIndex = 0;
            // 
            // panel13
            // 
            this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel13.Location = new System.Drawing.Point(33, 0);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(81, 27);
            this.panel13.TabIndex = 1;
            // 
            // panel14
            // 
            this.panel14.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel14.Location = new System.Drawing.Point(0, 95);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(114, 27);
            this.panel14.TabIndex = 1;
            // 
            // panel15
            // 
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(0, 27);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(114, 68);
            this.panel15.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(2, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 23);
            this.label2.TabIndex = 0;
            this.label2.Text = "1번";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_2
            // 
            this.CM_seat_2.Controls.Add(this.panel17);
            this.CM_seat_2.Controls.Add(this.panel18);
            this.CM_seat_2.Controls.Add(this.panel19);
            this.CM_seat_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_2.Location = new System.Drawing.Point(123, 3);
            this.CM_seat_2.Name = "CM_seat_2";
            this.CM_seat_2.Size = new System.Drawing.Size(114, 122);
            this.CM_seat_2.TabIndex = 1;
            // 
            // panel17
            // 
            this.panel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel17.Location = new System.Drawing.Point(0, 27);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(114, 68);
            this.panel17.TabIndex = 2;
            // 
            // panel18
            // 
            this.panel18.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel18.Location = new System.Drawing.Point(0, 95);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(114, 27);
            this.panel18.TabIndex = 1;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.panel20);
            this.panel19.Controls.Add(this.panel21);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel19.Location = new System.Drawing.Point(0, 0);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(114, 27);
            this.panel19.TabIndex = 0;
            // 
            // panel20
            // 
            this.panel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel20.Location = new System.Drawing.Point(33, 0);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(81, 27);
            this.panel20.TabIndex = 1;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.label3);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel21.Location = new System.Drawing.Point(0, 0);
            this.panel21.Name = "panel21";
            this.panel21.Padding = new System.Windows.Forms.Padding(2);
            this.panel21.Size = new System.Drawing.Size(33, 27);
            this.panel21.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(2, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 23);
            this.label3.TabIndex = 0;
            this.label3.Text = "2번";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_3
            // 
            this.CM_seat_3.Controls.Add(this.panel23);
            this.CM_seat_3.Controls.Add(this.panel24);
            this.CM_seat_3.Controls.Add(this.panel25);
            this.CM_seat_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_3.Location = new System.Drawing.Point(243, 3);
            this.CM_seat_3.Name = "CM_seat_3";
            this.CM_seat_3.Size = new System.Drawing.Size(114, 122);
            this.CM_seat_3.TabIndex = 2;
            // 
            // panel23
            // 
            this.panel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel23.Location = new System.Drawing.Point(0, 27);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(114, 68);
            this.panel23.TabIndex = 2;
            // 
            // panel24
            // 
            this.panel24.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel24.Location = new System.Drawing.Point(0, 95);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(114, 27);
            this.panel24.TabIndex = 1;
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.panel26);
            this.panel25.Controls.Add(this.panel27);
            this.panel25.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel25.Location = new System.Drawing.Point(0, 0);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(114, 27);
            this.panel25.TabIndex = 0;
            // 
            // panel26
            // 
            this.panel26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel26.Location = new System.Drawing.Point(33, 0);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(81, 27);
            this.panel26.TabIndex = 1;
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.label4);
            this.panel27.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel27.Location = new System.Drawing.Point(0, 0);
            this.panel27.Name = "panel27";
            this.panel27.Padding = new System.Windows.Forms.Padding(2);
            this.panel27.Size = new System.Drawing.Size(33, 27);
            this.panel27.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(2, 2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 23);
            this.label4.TabIndex = 0;
            this.label4.Text = "3번";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_4
            // 
            this.CM_seat_4.Controls.Add(this.panel29);
            this.CM_seat_4.Controls.Add(this.panel30);
            this.CM_seat_4.Controls.Add(this.panel31);
            this.CM_seat_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_4.Location = new System.Drawing.Point(363, 3);
            this.CM_seat_4.Name = "CM_seat_4";
            this.CM_seat_4.Size = new System.Drawing.Size(114, 122);
            this.CM_seat_4.TabIndex = 3;
            // 
            // panel29
            // 
            this.panel29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel29.Location = new System.Drawing.Point(0, 27);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(114, 68);
            this.panel29.TabIndex = 2;
            // 
            // panel30
            // 
            this.panel30.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel30.Location = new System.Drawing.Point(0, 95);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(114, 27);
            this.panel30.TabIndex = 1;
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.panel32);
            this.panel31.Controls.Add(this.panel33);
            this.panel31.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel31.Location = new System.Drawing.Point(0, 0);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(114, 27);
            this.panel31.TabIndex = 0;
            // 
            // panel32
            // 
            this.panel32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel32.Location = new System.Drawing.Point(33, 0);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(81, 27);
            this.panel32.TabIndex = 1;
            // 
            // panel33
            // 
            this.panel33.Controls.Add(this.label5);
            this.panel33.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel33.Location = new System.Drawing.Point(0, 0);
            this.panel33.Name = "panel33";
            this.panel33.Padding = new System.Windows.Forms.Padding(2);
            this.panel33.Size = new System.Drawing.Size(33, 27);
            this.panel33.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(2, 2);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 23);
            this.label5.TabIndex = 0;
            this.label5.Text = "4번";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_5
            // 
            this.CM_seat_5.Controls.Add(this.panel35);
            this.CM_seat_5.Controls.Add(this.panel36);
            this.CM_seat_5.Controls.Add(this.panel37);
            this.CM_seat_5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_5.Location = new System.Drawing.Point(483, 3);
            this.CM_seat_5.Name = "CM_seat_5";
            this.CM_seat_5.Size = new System.Drawing.Size(115, 122);
            this.CM_seat_5.TabIndex = 4;
            // 
            // panel35
            // 
            this.panel35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel35.Location = new System.Drawing.Point(0, 27);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(115, 68);
            this.panel35.TabIndex = 2;
            // 
            // panel36
            // 
            this.panel36.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel36.Location = new System.Drawing.Point(0, 95);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(115, 27);
            this.panel36.TabIndex = 1;
            // 
            // panel37
            // 
            this.panel37.Controls.Add(this.panel38);
            this.panel37.Controls.Add(this.panel39);
            this.panel37.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel37.Location = new System.Drawing.Point(0, 0);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(115, 27);
            this.panel37.TabIndex = 0;
            // 
            // panel38
            // 
            this.panel38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel38.Location = new System.Drawing.Point(33, 0);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(82, 27);
            this.panel38.TabIndex = 1;
            // 
            // panel39
            // 
            this.panel39.Controls.Add(this.label6);
            this.panel39.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel39.Location = new System.Drawing.Point(0, 0);
            this.panel39.Name = "panel39";
            this.panel39.Padding = new System.Windows.Forms.Padding(2);
            this.panel39.Size = new System.Drawing.Size(33, 27);
            this.panel39.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Location = new System.Drawing.Point(2, 2);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 23);
            this.label6.TabIndex = 0;
            this.label6.Text = "5번";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_6
            // 
            this.CM_seat_6.Controls.Add(this.panel41);
            this.CM_seat_6.Controls.Add(this.panel42);
            this.CM_seat_6.Controls.Add(this.panel43);
            this.CM_seat_6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_6.Location = new System.Drawing.Point(3, 131);
            this.CM_seat_6.Name = "CM_seat_6";
            this.CM_seat_6.Size = new System.Drawing.Size(114, 122);
            this.CM_seat_6.TabIndex = 5;
            // 
            // panel41
            // 
            this.panel41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel41.Location = new System.Drawing.Point(0, 27);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(114, 68);
            this.panel41.TabIndex = 2;
            // 
            // panel42
            // 
            this.panel42.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel42.Location = new System.Drawing.Point(0, 95);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(114, 27);
            this.panel42.TabIndex = 1;
            // 
            // panel43
            // 
            this.panel43.Controls.Add(this.panel44);
            this.panel43.Controls.Add(this.panel45);
            this.panel43.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel43.Location = new System.Drawing.Point(0, 0);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(114, 27);
            this.panel43.TabIndex = 0;
            // 
            // panel44
            // 
            this.panel44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel44.Location = new System.Drawing.Point(33, 0);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(81, 27);
            this.panel44.TabIndex = 1;
            // 
            // panel45
            // 
            this.panel45.Controls.Add(this.label7);
            this.panel45.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel45.Location = new System.Drawing.Point(0, 0);
            this.panel45.Name = "panel45";
            this.panel45.Padding = new System.Windows.Forms.Padding(2);
            this.panel45.Size = new System.Drawing.Size(33, 27);
            this.panel45.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Location = new System.Drawing.Point(2, 2);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 23);
            this.label7.TabIndex = 0;
            this.label7.Text = "6번";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_7
            // 
            this.CM_seat_7.Controls.Add(this.panel47);
            this.CM_seat_7.Controls.Add(this.panel48);
            this.CM_seat_7.Controls.Add(this.panel49);
            this.CM_seat_7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_7.Location = new System.Drawing.Point(123, 131);
            this.CM_seat_7.Name = "CM_seat_7";
            this.CM_seat_7.Size = new System.Drawing.Size(114, 122);
            this.CM_seat_7.TabIndex = 6;
            // 
            // panel47
            // 
            this.panel47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel47.Location = new System.Drawing.Point(0, 27);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(114, 68);
            this.panel47.TabIndex = 2;
            // 
            // panel48
            // 
            this.panel48.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel48.Location = new System.Drawing.Point(0, 95);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(114, 27);
            this.panel48.TabIndex = 1;
            // 
            // panel49
            // 
            this.panel49.Controls.Add(this.panel50);
            this.panel49.Controls.Add(this.panel51);
            this.panel49.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel49.Location = new System.Drawing.Point(0, 0);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(114, 27);
            this.panel49.TabIndex = 0;
            // 
            // panel50
            // 
            this.panel50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel50.Location = new System.Drawing.Point(33, 0);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(81, 27);
            this.panel50.TabIndex = 1;
            // 
            // panel51
            // 
            this.panel51.Controls.Add(this.label8);
            this.panel51.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel51.Location = new System.Drawing.Point(0, 0);
            this.panel51.Name = "panel51";
            this.panel51.Padding = new System.Windows.Forms.Padding(2);
            this.panel51.Size = new System.Drawing.Size(33, 27);
            this.panel51.TabIndex = 0;
            // 
            // label8
            // 
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Location = new System.Drawing.Point(2, 2);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 23);
            this.label8.TabIndex = 0;
            this.label8.Text = "7번";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_8
            // 
            this.CM_seat_8.Controls.Add(this.panel53);
            this.CM_seat_8.Controls.Add(this.panel54);
            this.CM_seat_8.Controls.Add(this.panel55);
            this.CM_seat_8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_8.Location = new System.Drawing.Point(243, 131);
            this.CM_seat_8.Name = "CM_seat_8";
            this.CM_seat_8.Size = new System.Drawing.Size(114, 122);
            this.CM_seat_8.TabIndex = 7;
            // 
            // panel53
            // 
            this.panel53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel53.Location = new System.Drawing.Point(0, 27);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(114, 68);
            this.panel53.TabIndex = 2;
            // 
            // panel54
            // 
            this.panel54.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel54.Location = new System.Drawing.Point(0, 95);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(114, 27);
            this.panel54.TabIndex = 1;
            // 
            // panel55
            // 
            this.panel55.Controls.Add(this.panel56);
            this.panel55.Controls.Add(this.panel57);
            this.panel55.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel55.Location = new System.Drawing.Point(0, 0);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(114, 27);
            this.panel55.TabIndex = 0;
            // 
            // panel56
            // 
            this.panel56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel56.Location = new System.Drawing.Point(33, 0);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(81, 27);
            this.panel56.TabIndex = 1;
            // 
            // panel57
            // 
            this.panel57.Controls.Add(this.label9);
            this.panel57.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel57.Location = new System.Drawing.Point(0, 0);
            this.panel57.Name = "panel57";
            this.panel57.Padding = new System.Windows.Forms.Padding(2);
            this.panel57.Size = new System.Drawing.Size(33, 27);
            this.panel57.TabIndex = 0;
            // 
            // label9
            // 
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Location = new System.Drawing.Point(2, 2);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 23);
            this.label9.TabIndex = 0;
            this.label9.Text = "8번";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_9
            // 
            this.CM_seat_9.Controls.Add(this.panel59);
            this.CM_seat_9.Controls.Add(this.panel60);
            this.CM_seat_9.Controls.Add(this.panel61);
            this.CM_seat_9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_9.Location = new System.Drawing.Point(363, 131);
            this.CM_seat_9.Name = "CM_seat_9";
            this.CM_seat_9.Size = new System.Drawing.Size(114, 122);
            this.CM_seat_9.TabIndex = 8;
            // 
            // panel59
            // 
            this.panel59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel59.Location = new System.Drawing.Point(0, 27);
            this.panel59.Name = "panel59";
            this.panel59.Size = new System.Drawing.Size(114, 68);
            this.panel59.TabIndex = 2;
            // 
            // panel60
            // 
            this.panel60.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel60.Location = new System.Drawing.Point(0, 95);
            this.panel60.Name = "panel60";
            this.panel60.Size = new System.Drawing.Size(114, 27);
            this.panel60.TabIndex = 1;
            // 
            // panel61
            // 
            this.panel61.Controls.Add(this.panel62);
            this.panel61.Controls.Add(this.panel63);
            this.panel61.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel61.Location = new System.Drawing.Point(0, 0);
            this.panel61.Name = "panel61";
            this.panel61.Size = new System.Drawing.Size(114, 27);
            this.panel61.TabIndex = 0;
            // 
            // panel62
            // 
            this.panel62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel62.Location = new System.Drawing.Point(33, 0);
            this.panel62.Name = "panel62";
            this.panel62.Size = new System.Drawing.Size(81, 27);
            this.panel62.TabIndex = 1;
            // 
            // panel63
            // 
            this.panel63.Controls.Add(this.label10);
            this.panel63.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel63.Location = new System.Drawing.Point(0, 0);
            this.panel63.Name = "panel63";
            this.panel63.Padding = new System.Windows.Forms.Padding(2);
            this.panel63.Size = new System.Drawing.Size(33, 27);
            this.panel63.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Location = new System.Drawing.Point(2, 2);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 23);
            this.label10.TabIndex = 0;
            this.label10.Text = "9번";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_10
            // 
            this.CM_seat_10.Controls.Add(this.panel65);
            this.CM_seat_10.Controls.Add(this.panel66);
            this.CM_seat_10.Controls.Add(this.panel67);
            this.CM_seat_10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_10.Location = new System.Drawing.Point(483, 131);
            this.CM_seat_10.Name = "CM_seat_10";
            this.CM_seat_10.Size = new System.Drawing.Size(115, 122);
            this.CM_seat_10.TabIndex = 9;
            // 
            // panel65
            // 
            this.panel65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel65.Location = new System.Drawing.Point(0, 27);
            this.panel65.Name = "panel65";
            this.panel65.Size = new System.Drawing.Size(115, 68);
            this.panel65.TabIndex = 2;
            // 
            // panel66
            // 
            this.panel66.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel66.Location = new System.Drawing.Point(0, 95);
            this.panel66.Name = "panel66";
            this.panel66.Size = new System.Drawing.Size(115, 27);
            this.panel66.TabIndex = 1;
            // 
            // panel67
            // 
            this.panel67.Controls.Add(this.panel68);
            this.panel67.Controls.Add(this.panel69);
            this.panel67.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel67.Location = new System.Drawing.Point(0, 0);
            this.panel67.Name = "panel67";
            this.panel67.Size = new System.Drawing.Size(115, 27);
            this.panel67.TabIndex = 0;
            // 
            // panel68
            // 
            this.panel68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel68.Location = new System.Drawing.Point(33, 0);
            this.panel68.Name = "panel68";
            this.panel68.Size = new System.Drawing.Size(82, 27);
            this.panel68.TabIndex = 1;
            // 
            // panel69
            // 
            this.panel69.Controls.Add(this.label11);
            this.panel69.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel69.Location = new System.Drawing.Point(0, 0);
            this.panel69.Name = "panel69";
            this.panel69.Padding = new System.Windows.Forms.Padding(2);
            this.panel69.Size = new System.Drawing.Size(33, 27);
            this.panel69.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Location = new System.Drawing.Point(2, 2);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 23);
            this.label11.TabIndex = 0;
            this.label11.Text = "10번";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_11
            // 
            this.CM_seat_11.Controls.Add(this.panel71);
            this.CM_seat_11.Controls.Add(this.panel72);
            this.CM_seat_11.Controls.Add(this.panel73);
            this.CM_seat_11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_11.Location = new System.Drawing.Point(3, 259);
            this.CM_seat_11.Name = "CM_seat_11";
            this.CM_seat_11.Size = new System.Drawing.Size(114, 124);
            this.CM_seat_11.TabIndex = 10;
            // 
            // panel71
            // 
            this.panel71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel71.Location = new System.Drawing.Point(0, 27);
            this.panel71.Name = "panel71";
            this.panel71.Size = new System.Drawing.Size(114, 70);
            this.panel71.TabIndex = 2;
            // 
            // panel72
            // 
            this.panel72.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel72.Location = new System.Drawing.Point(0, 97);
            this.panel72.Name = "panel72";
            this.panel72.Size = new System.Drawing.Size(114, 27);
            this.panel72.TabIndex = 1;
            // 
            // panel73
            // 
            this.panel73.Controls.Add(this.panel74);
            this.panel73.Controls.Add(this.panel75);
            this.panel73.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel73.Location = new System.Drawing.Point(0, 0);
            this.panel73.Name = "panel73";
            this.panel73.Size = new System.Drawing.Size(114, 27);
            this.panel73.TabIndex = 0;
            // 
            // panel74
            // 
            this.panel74.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel74.Location = new System.Drawing.Point(33, 0);
            this.panel74.Name = "panel74";
            this.panel74.Size = new System.Drawing.Size(81, 27);
            this.panel74.TabIndex = 1;
            // 
            // panel75
            // 
            this.panel75.Controls.Add(this.label12);
            this.panel75.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel75.Location = new System.Drawing.Point(0, 0);
            this.panel75.Name = "panel75";
            this.panel75.Padding = new System.Windows.Forms.Padding(2);
            this.panel75.Size = new System.Drawing.Size(33, 27);
            this.panel75.TabIndex = 0;
            // 
            // label12
            // 
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Location = new System.Drawing.Point(2, 2);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 23);
            this.label12.TabIndex = 0;
            this.label12.Text = "11번";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_12
            // 
            this.CM_seat_12.Controls.Add(this.panel77);
            this.CM_seat_12.Controls.Add(this.panel78);
            this.CM_seat_12.Controls.Add(this.panel79);
            this.CM_seat_12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_12.Location = new System.Drawing.Point(123, 259);
            this.CM_seat_12.Name = "CM_seat_12";
            this.CM_seat_12.Size = new System.Drawing.Size(114, 124);
            this.CM_seat_12.TabIndex = 11;
            // 
            // panel77
            // 
            this.panel77.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel77.Location = new System.Drawing.Point(0, 27);
            this.panel77.Name = "panel77";
            this.panel77.Size = new System.Drawing.Size(114, 70);
            this.panel77.TabIndex = 2;
            // 
            // panel78
            // 
            this.panel78.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel78.Location = new System.Drawing.Point(0, 97);
            this.panel78.Name = "panel78";
            this.panel78.Size = new System.Drawing.Size(114, 27);
            this.panel78.TabIndex = 1;
            // 
            // panel79
            // 
            this.panel79.Controls.Add(this.panel80);
            this.panel79.Controls.Add(this.panel81);
            this.panel79.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel79.Location = new System.Drawing.Point(0, 0);
            this.panel79.Name = "panel79";
            this.panel79.Size = new System.Drawing.Size(114, 27);
            this.panel79.TabIndex = 0;
            // 
            // panel80
            // 
            this.panel80.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel80.Location = new System.Drawing.Point(33, 0);
            this.panel80.Name = "panel80";
            this.panel80.Size = new System.Drawing.Size(81, 27);
            this.panel80.TabIndex = 1;
            // 
            // panel81
            // 
            this.panel81.Controls.Add(this.label13);
            this.panel81.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel81.Location = new System.Drawing.Point(0, 0);
            this.panel81.Name = "panel81";
            this.panel81.Padding = new System.Windows.Forms.Padding(2);
            this.panel81.Size = new System.Drawing.Size(33, 27);
            this.panel81.TabIndex = 0;
            // 
            // label13
            // 
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Location = new System.Drawing.Point(2, 2);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 23);
            this.label13.TabIndex = 0;
            this.label13.Text = "12번";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_13
            // 
            this.CM_seat_13.Controls.Add(this.panel83);
            this.CM_seat_13.Controls.Add(this.panel84);
            this.CM_seat_13.Controls.Add(this.panel85);
            this.CM_seat_13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_13.Location = new System.Drawing.Point(243, 259);
            this.CM_seat_13.Name = "CM_seat_13";
            this.CM_seat_13.Size = new System.Drawing.Size(114, 124);
            this.CM_seat_13.TabIndex = 12;
            // 
            // panel83
            // 
            this.panel83.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel83.Location = new System.Drawing.Point(0, 27);
            this.panel83.Name = "panel83";
            this.panel83.Size = new System.Drawing.Size(114, 70);
            this.panel83.TabIndex = 2;
            // 
            // panel84
            // 
            this.panel84.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel84.Location = new System.Drawing.Point(0, 97);
            this.panel84.Name = "panel84";
            this.panel84.Size = new System.Drawing.Size(114, 27);
            this.panel84.TabIndex = 1;
            // 
            // panel85
            // 
            this.panel85.Controls.Add(this.panel86);
            this.panel85.Controls.Add(this.panel87);
            this.panel85.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel85.Location = new System.Drawing.Point(0, 0);
            this.panel85.Name = "panel85";
            this.panel85.Size = new System.Drawing.Size(114, 27);
            this.panel85.TabIndex = 0;
            // 
            // panel86
            // 
            this.panel86.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel86.Location = new System.Drawing.Point(33, 0);
            this.panel86.Name = "panel86";
            this.panel86.Size = new System.Drawing.Size(81, 27);
            this.panel86.TabIndex = 1;
            // 
            // panel87
            // 
            this.panel87.Controls.Add(this.label14);
            this.panel87.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel87.Location = new System.Drawing.Point(0, 0);
            this.panel87.Name = "panel87";
            this.panel87.Padding = new System.Windows.Forms.Padding(2);
            this.panel87.Size = new System.Drawing.Size(33, 27);
            this.panel87.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Location = new System.Drawing.Point(2, 2);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 23);
            this.label14.TabIndex = 0;
            this.label14.Text = "13번";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_14
            // 
            this.CM_seat_14.Controls.Add(this.panel89);
            this.CM_seat_14.Controls.Add(this.panel90);
            this.CM_seat_14.Controls.Add(this.panel91);
            this.CM_seat_14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_14.Location = new System.Drawing.Point(363, 259);
            this.CM_seat_14.Name = "CM_seat_14";
            this.CM_seat_14.Size = new System.Drawing.Size(114, 124);
            this.CM_seat_14.TabIndex = 13;
            // 
            // panel89
            // 
            this.panel89.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel89.Location = new System.Drawing.Point(0, 27);
            this.panel89.Name = "panel89";
            this.panel89.Size = new System.Drawing.Size(114, 70);
            this.panel89.TabIndex = 2;
            // 
            // panel90
            // 
            this.panel90.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel90.Location = new System.Drawing.Point(0, 97);
            this.panel90.Name = "panel90";
            this.panel90.Size = new System.Drawing.Size(114, 27);
            this.panel90.TabIndex = 1;
            // 
            // panel91
            // 
            this.panel91.Controls.Add(this.panel92);
            this.panel91.Controls.Add(this.panel93);
            this.panel91.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel91.Location = new System.Drawing.Point(0, 0);
            this.panel91.Name = "panel91";
            this.panel91.Size = new System.Drawing.Size(114, 27);
            this.panel91.TabIndex = 0;
            // 
            // panel92
            // 
            this.panel92.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel92.Location = new System.Drawing.Point(33, 0);
            this.panel92.Name = "panel92";
            this.panel92.Size = new System.Drawing.Size(81, 27);
            this.panel92.TabIndex = 1;
            // 
            // panel93
            // 
            this.panel93.Controls.Add(this.label15);
            this.panel93.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel93.Location = new System.Drawing.Point(0, 0);
            this.panel93.Name = "panel93";
            this.panel93.Padding = new System.Windows.Forms.Padding(2);
            this.panel93.Size = new System.Drawing.Size(33, 27);
            this.panel93.TabIndex = 0;
            // 
            // label15
            // 
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Location = new System.Drawing.Point(2, 2);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(29, 23);
            this.label15.TabIndex = 0;
            this.label15.Text = "14번";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_15
            // 
            this.CM_seat_15.Controls.Add(this.panel95);
            this.CM_seat_15.Controls.Add(this.panel96);
            this.CM_seat_15.Controls.Add(this.panel97);
            this.CM_seat_15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_15.Location = new System.Drawing.Point(483, 259);
            this.CM_seat_15.Name = "CM_seat_15";
            this.CM_seat_15.Size = new System.Drawing.Size(115, 124);
            this.CM_seat_15.TabIndex = 14;
            // 
            // panel95
            // 
            this.panel95.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel95.Location = new System.Drawing.Point(0, 27);
            this.panel95.Name = "panel95";
            this.panel95.Size = new System.Drawing.Size(115, 70);
            this.panel95.TabIndex = 2;
            // 
            // panel96
            // 
            this.panel96.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel96.Location = new System.Drawing.Point(0, 97);
            this.panel96.Name = "panel96";
            this.panel96.Size = new System.Drawing.Size(115, 27);
            this.panel96.TabIndex = 1;
            // 
            // panel97
            // 
            this.panel97.Controls.Add(this.panel98);
            this.panel97.Controls.Add(this.panel99);
            this.panel97.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel97.Location = new System.Drawing.Point(0, 0);
            this.panel97.Name = "panel97";
            this.panel97.Size = new System.Drawing.Size(115, 27);
            this.panel97.TabIndex = 0;
            // 
            // panel98
            // 
            this.panel98.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel98.Location = new System.Drawing.Point(33, 0);
            this.panel98.Name = "panel98";
            this.panel98.Size = new System.Drawing.Size(82, 27);
            this.panel98.TabIndex = 1;
            // 
            // panel99
            // 
            this.panel99.Controls.Add(this.label16);
            this.panel99.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel99.Location = new System.Drawing.Point(0, 0);
            this.panel99.Name = "panel99";
            this.panel99.Padding = new System.Windows.Forms.Padding(2);
            this.panel99.Size = new System.Drawing.Size(33, 27);
            this.panel99.TabIndex = 0;
            // 
            // label16
            // 
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Location = new System.Drawing.Point(2, 2);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 23);
            this.label16.TabIndex = 0;
            this.label16.Text = "15번";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // counter_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(844, 452);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "counter_main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel10.ResumeLayout(false);
            this.menu.ResumeLayout(false);
            this.CM_seat_1.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.CM_seat_2.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.CM_seat_3.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.CM_seat_4.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel33.ResumeLayout(false);
            this.CM_seat_5.ResumeLayout(false);
            this.panel37.ResumeLayout(false);
            this.panel39.ResumeLayout(false);
            this.CM_seat_6.ResumeLayout(false);
            this.panel43.ResumeLayout(false);
            this.panel45.ResumeLayout(false);
            this.CM_seat_7.ResumeLayout(false);
            this.panel49.ResumeLayout(false);
            this.panel51.ResumeLayout(false);
            this.CM_seat_8.ResumeLayout(false);
            this.panel55.ResumeLayout(false);
            this.panel57.ResumeLayout(false);
            this.CM_seat_9.ResumeLayout(false);
            this.panel61.ResumeLayout(false);
            this.panel63.ResumeLayout(false);
            this.CM_seat_10.ResumeLayout(false);
            this.panel67.ResumeLayout(false);
            this.panel69.ResumeLayout(false);
            this.CM_seat_11.ResumeLayout(false);
            this.panel73.ResumeLayout(false);
            this.panel75.ResumeLayout(false);
            this.CM_seat_12.ResumeLayout(false);
            this.panel79.ResumeLayout(false);
            this.panel81.ResumeLayout(false);
            this.CM_seat_13.ResumeLayout(false);
            this.panel85.ResumeLayout(false);
            this.panel87.ResumeLayout(false);
            this.CM_seat_14.ResumeLayout(false);
            this.panel91.ResumeLayout(false);
            this.panel93.ResumeLayout(false);
            this.CM_seat_15.ResumeLayout(false);
            this.panel97.ResumeLayout(false);
            this.panel99.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button CM_screen_lock;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button CM_product_mg;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button CM_member_mg;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ContextMenuStrip menu;
        private System.Windows.Forms.ToolStripMenuItem CM_payment;
        private System.Windows.Forms.ToolStripMenuItem CM_system;
        private System.Windows.Forms.ToolStripMenuItem CM_system_shutdown;
        private System.Windows.Forms.ToolStripMenuItem CM_system_restart;
        private System.Windows.Forms.ToolStripMenuItem CM_add_time;
        private System.Windows.Forms.ToolStripMenuItem CM_add_time_1hour;
        private System.Windows.Forms.ToolStripMenuItem CM_add_time_2hour;
        private System.Windows.Forms.ToolStripMenuItem CM_add_time_3hour;
        private System.Windows.Forms.ToolStripMenuItem CM_add_time_5hour;
        private System.Windows.Forms.ToolStripMenuItem CM_reserved;
        private System.Windows.Forms.ToolStripMenuItem CM_breakdown;
        private System.Windows.Forms.ToolStripMenuItem CM_Shift;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel CM_seat_15;
        private System.Windows.Forms.Panel panel95;
        private System.Windows.Forms.Panel panel96;
        private System.Windows.Forms.Panel panel97;
        private System.Windows.Forms.Panel panel98;
        private System.Windows.Forms.Panel panel99;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel CM_seat_14;
        private System.Windows.Forms.Panel panel89;
        private System.Windows.Forms.Panel panel90;
        private System.Windows.Forms.Panel panel91;
        private System.Windows.Forms.Panel panel92;
        private System.Windows.Forms.Panel panel93;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel CM_seat_13;
        private System.Windows.Forms.Panel panel83;
        private System.Windows.Forms.Panel panel84;
        private System.Windows.Forms.Panel panel85;
        private System.Windows.Forms.Panel panel86;
        private System.Windows.Forms.Panel panel87;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel CM_seat_12;
        private System.Windows.Forms.Panel panel77;
        private System.Windows.Forms.Panel panel78;
        private System.Windows.Forms.Panel panel79;
        private System.Windows.Forms.Panel panel80;
        private System.Windows.Forms.Panel panel81;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel CM_seat_11;
        private System.Windows.Forms.Panel panel71;
        private System.Windows.Forms.Panel panel72;
        private System.Windows.Forms.Panel panel73;
        private System.Windows.Forms.Panel panel74;
        private System.Windows.Forms.Panel panel75;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel CM_seat_10;
        private System.Windows.Forms.Panel panel65;
        private System.Windows.Forms.Panel panel66;
        private System.Windows.Forms.Panel panel67;
        private System.Windows.Forms.Panel panel68;
        private System.Windows.Forms.Panel panel69;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel CM_seat_9;
        private System.Windows.Forms.Panel panel59;
        private System.Windows.Forms.Panel panel60;
        private System.Windows.Forms.Panel panel61;
        private System.Windows.Forms.Panel panel62;
        private System.Windows.Forms.Panel panel63;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel CM_seat_8;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.Panel panel57;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel CM_seat_7;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel CM_seat_6;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel CM_seat_5;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel CM_seat_4;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel CM_seat_3;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel CM_seat_2;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel CM_seat_1;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label2;
    }
}

