﻿using Player_pc.Manager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Player_pc.Windows.Pop {
    public partial class JoinPop : Form {
        public JoinPop() {
            InitializeComponent();
        }

        //회원추가 DB저장
        private void AddnewMember() {



        }

        private void jbtn_double_check_Click(object sender, EventArgs e) {

            string _admb_id = Join_tbox_id.Text;

            DataRow _row = App.Self().DBManager.ReadMember_byid(_admb_id);
            if (_row != null) {
                MessageBox.Show(String.Format("{0}는(은) 사용중인 아이디입니다.", _admb_id));
                Join_tbox_id.Focus(); Join_tbox_id.SelectAll();
                return;
            }
            else {
                MessageBox.Show(String.Format("사용가능한 아이디입니다.", _admb_id));
                jbtn_join.Enabled = true;
            }

        }


        private void jbtn_join_Click(object sender, EventArgs e) {

            
                string _addmb_name = Join_tbox_name.Text;
                string _addmb_id = Join_tbox_id.Text;
                string _addmb_pw = Join_tbox_pw.Text;
                string _addmb_ph = Join_tbox_ph.Text;
                DateTime _addmb_birthdate = Join_tbox_birth.Value;
                int _result = App.Self().DBManager.Addmember(_addmb_name,
                _addmb_id, _addmb_pw, _addmb_ph, _addmb_birthdate);
            if (_result > 0) {
                    MessageBox.Show($"{_addmb_name}님 환영합니다");
                //MBM_add_member.
                DialogResult = DialogResult.Cancel;
            }
                else {
                    MessageBox.Show("추가실패");
                }

            }

        private void jbtn_join_Click_1(object sender, EventArgs e) {
            
            
            
            string _addmb_name = Join_tbox_name.Text;
            string _addmb_id = Join_tbox_id.Text;
            string _addmb_pw = Join_tbox_pw.Text;
            string _addmb_ph = Join_tbox_ph.Text;
            DateTime _addmb_birthdate = Join_tbox_birth.Value;

            int _result = App.Self().DBManager.Addmember(_addmb_name,
            _addmb_id, _addmb_pw, _addmb_ph, _addmb_birthdate);
            if (_result > 0) {
                MessageBox.Show($"{_addmb_name}님 환영합니다");
                //MBM_add_member.
                DialogResult = DialogResult.Cancel;
            }
            else {
                MessageBox.Show("추가실패");
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e) {

        }
    }

    
 }
