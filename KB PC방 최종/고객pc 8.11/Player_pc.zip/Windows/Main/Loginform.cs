﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Player_pc.Windows.Pop;
using Lib.Util;
using Lib.DB;

namespace Player_pc {
    public partial class Loginform : Form {
        IniAssist m_iniAssist;
        public string Addr { get { return Convert.ToString("192.168.0.208"); } }
        public int Port { get { return Convert.ToInt32(1521); } }
        public string Id { get { return Convert.ToString("pc"); } }
        public string Pwd { get { return Convert.ToString("kb603"); } }
        public string Database { get { return Convert.ToString("xe"); } }

        public Loginform() {
            DBconnect();
            InitializeComponent();
        }


        private void DBconnect() {            
            //19접속테스트하기
            OracleAssist _OracleAssist = new OracleAssist(Addr, Port, Id, Pwd, Database);
            bool _Success = _OracleAssist.TestConnection();
            if (_Success) {
                MessageBox.Show("오라클 접속성공");
            }
            else {
                MessageBox.Show("오라클 접속실패");
            }
        }

        private void button4_Click(object sender, EventArgs e) {

        }

        private void Log_join_btn_Click(object sender, EventArgs e) {
            JoinPop _pop = new JoinPop();
            if (_pop.ShowDialog(this) == DialogResult.OK) {

            }
        }

        private void Log_find_id_Click(object sender, EventArgs e) {
            FindIdPop _pop = new FindIdPop();
            if (_pop.ShowDialog(this) == DialogResult.OK) {

            }
        }

        private void Log_find_pw_Click(object sender, EventArgs e) {
            FindPwPop _pop = new FindPwPop();
            if (_pop.ShowDialog(this) == DialogResult.OK) {

            }
        }
    }
}
